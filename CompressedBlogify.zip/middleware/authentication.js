const { validateUserToken } = require("../services/authentication");

function authenticationCookie(cookieName){
  return(req,res,next)=>{
    const tokenCookieVAlue=req.cookies[cookieName]
    if(!tokenCookieVAlue){
      return next();
    }
    try{
      const userPayload=validateUserToken(tokenCookieVAlue);
      req.user=userPayload;
    }
    catch(error){

    }
    return next();

    

  }
}

module.exports={
  authenticationCookie
}